

(define (problem BW-rand-4)
(:domain blocksworld-4ops)
(:objects a b c d )
(:init
(handempty)
(on a c)
(ontable b)
(ontable c)
(ontable d)
(clear a)
(clear b)
(clear d)
)
(:goal
(and
(on a c)
(on c d)
(on d b))
)
)


